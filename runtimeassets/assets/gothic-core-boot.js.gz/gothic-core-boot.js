// gothic-core-boot.js — boots the Gothic full-Go static core once per page.
// Loaded once from the layout <head>. Instantiates public/gothic-core.wasm through
// its own wasm_exec slot so the standard-Go `Go` constructor coexists with TinyGo
// components. A __gothicCoreBooting latch guards against a double boot; it is CLEARED
// on exec-load or instantiate failure so a later attempt (e.g. an HTMX fragment) can
// retry rather than wedge the page. Interpreted by nothing but the browser.
(function(){
    if(window.__gothicCoreBooting)return;
    window.__gothicCoreBooting=1;
    var EXEC='/_gothic/gothic-core-exec.js?v=0c949f4996f9a896';
    var CORE='/_gothic/gothic-core.wasm?v=478487872ce1cef6';
    var SLOT='gothic-core-exec.js';
    function boot(){
        if(!window.__gothicGoClasses)window.__gothicGoClasses={};
        var GoCls=window.__gothicGoClasses[SLOT];
        if(!GoCls){window.__gothicCoreBooting=0;try{console.error('gothic: core exec class missing');}catch(_){}return;}
        var go=new GoCls();
        fetch(CORE).then(function(resp){return resp.arrayBuffer();})
            .then(function(buf){return WebAssembly.instantiate(buf,go.importObject);})
            .then(function(res){go.run(res.instance);})
            .catch(function(e){window.__gothicCoreBooting=0;try{console.error('gothic: core boot failed',e);}catch(_){}});
    }
    if(window.__gothicGoClasses&&window.__gothicGoClasses[SLOT]){boot();return;}
    var prevGo=(typeof Go!=='undefined')?Go:undefined;
    var s=document.createElement('script');
    s.src=EXEC;
    s.onload=function(){
        if(!window.__gothicGoClasses)window.__gothicGoClasses={};
        if(!window.__gothicGoClasses[SLOT])window.__gothicGoClasses[SLOT]=Go;
        if(prevGo!==undefined){try{window.Go=prevGo;}catch(_){}}
        boot();
    };
    s.onerror=function(e){window.__gothicCoreBooting=0;try{console.error('gothic: core exec load failed',e);}catch(_){}};
    document.head.appendChild(s);
})();
